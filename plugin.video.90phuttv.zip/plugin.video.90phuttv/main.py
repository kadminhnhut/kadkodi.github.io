from urllib.parse import urlencode, parse_qsl
import sys, xbmcgui, xbmcplugin, requests, os, re
import xbmcaddon, xbmc, urllib.request
import shutil, zipfile

info_update = "https://hoaivnpt.duckdns.org/addon_kodi/90phuttv/ver.txt"
download_url = "https://hoaivnpt.duckdns.org/addon_kodi/90phuttv/plugin.video.90phuttv.zip"
addon = xbmcaddon.Addon()
current_version = addon.getAddonInfo('version')
response = requests.get(info_update)
if response.status_code == 200:
    latest_version = response.content.decode('ISO-8859-1')
    if latest_version != current_version:
        temp_dir = os.path.join(addon.getAddonInfo('path'), 'temp')
        os.makedirs(temp_dir, exist_ok=True)
        response = requests.get(download_url)
        if response.status_code == 200:
            zip_file = os.path.join(temp_dir, 'update.zip')
            with open(zip_file, 'wb') as f:
                f.write(response.content)
            with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            extracted_dir = os.path.join(temp_dir, addon.getAddonInfo('id'))
            addon_dir = addon.getAddonInfo('path')
            src_files = os.listdir(extracted_dir)
            for file_name in src_files:
                full_file_name = os.path.join(extracted_dir, file_name)
                shutil.move(full_file_name, addon_dir + file_name)
            shutil.rmtree(temp_dir)
            dialog = xbmcgui.Dialog()
            dialog.ok('Đã cập nhật phiên bản mới', 'Vui lòng khởi động lại Kodi để cập nhật có hiệu lực.')
            

base_url = sys.argv[0]
HANDLE = int(sys.argv[1])

def get_url(**kwargs):
    return base_url + '?' + urlencode(kwargs)

def list_genres(link, isfolder):
    respjs = requests.get(link, timeout=15).json()
    for k in respjs:
        name = k["name"]
        match = k["url"]
        logo = k["logo"]
        fanart = k["fanart"]
        desc = k["desc"]
        isfolder = k["isfolder"]
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        if isfolder == "True":
            list_item.setProperty("IsPlayable", 'false')
            url = get_url(action='list_link', link=match)
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        else:
            list_item.setProperty("IsPlayable", 'true')
            xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def router(string):
    params = dict(parse_qsl(string))
    if not params:
        list_genres('https://www.dropbox.com/scl/fi/pntssitspmuz8p1bz4a7j/90phuttv_addon.txt?rlkey=nmvti4si5j01p60ycfvj2k4cv&dl=1', True)
    elif params['action'] == 'list_link':
        list_genres(params['link'], True)
    else:
        raise ValueError(f'Invalid paramstring: {string}!')

if __name__ == '__main__':
    router(sys.argv[2][1:])